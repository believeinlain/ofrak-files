"S16BSBE","S16BSLE","dtswap16f.c","dtswap16t.c",2,
"S16BUBE","S16BULE","dtswap16f.c","dtswap16t.c",2,
"S32BSBE","S32BSLE","dtswap32f.c","dtswap32t.c",4,
"S32BUBE","S32BULE","dtswap32f.c","dtswap32t.c",4,
"S64BSBE","S64BSLE","dtswap64f.c","dtswap64t.c",8,
"S64BUBE","S64BULE","dtswap64f.c","dtswap64t.c",8,
"S32BIEEEBE","S32BIEEELE","dtswap32f.c","dtswap32t.c",4,
"S64BIEEEBE","S64BIEEELE","dtswap64f.c","dtswap64t.c",8,
"S16BSLE","S16BSBE","dtswap16f.c","dtswap16t.c",2,
"S16BULE","S16BUBE","dtswap16f.c","dtswap16t.c",2,
"S32BSLE","S32BSBE","dtswap32f.c","dtswap32t.c",4,
"S32BULE","S32BUBE","dtswap32f.c","dtswap32t.c",4,
"S64BSLE","S64BSBE","dtswap64f.c","dtswap64t.c",8,
"S64BULE","S64BUBE","dtswap64f.c","dtswap64t.c",8,
"S32BIEEELE","S32BIEEEBE","dtswap32f.c","dtswap32t.c",4,
"S64BIEEELE","S64BIEEEBE","dtswap64f.c","dtswap64t.c",8,

#include "dtwidths.h"


